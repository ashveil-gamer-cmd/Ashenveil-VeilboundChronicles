// ═══════ ASHENVEIL GAME ENGINE ═══════

// ═══════════════════════════════════════════════════════════
// ASHENVEIL: VEILBOUND CHRONICLES — ENGINE v4
// Full rewrite: rich visuals, working music, smooth gameplay
// ═══════════════════════════════════════════════════════════

const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
let W, H;
function resize(){ W=canvas.width=window.innerWidth; H=canvas.height=window.innerHeight; }
resize(); window.addEventListener('resize',resize);


// ═══════ ABILITY ICONS ════════════════════════════════
function drawAbilityIcons(){
  const icons=[
    (c,x)=>{
      x.clearRect(0,0,38,38);
      // Ghost with glow
      const g=x.createRadialGradient(19,19,0,19,19,16);
      g.addColorStop(0,'#c4b5fd');g.addColorStop(1,'rgba(196,181,253,0)');
      x.fillStyle=g;x.beginPath();x.arc(19,19,16,0,Math.PI*2);x.fill();
      x.shadowColor='#9DC4B0';x.shadowBlur=10;
      x.fillStyle='#9DC4B0';x.beginPath();x.arc(19,13,9,Math.PI,0);
      x.lineTo(28,25);for(let i=0;i<3;i++)x.arc(25-i*4.5,25,2.2,0,Math.PI,true);
      x.lineTo(10,25);x.closePath();x.fill();
      x.fillStyle='#0a0020';x.beginPath();x.arc(16,12,2.5,0,Math.PI*2);x.fill();
      x.beginPath();x.arc(22,12,2.5,0,Math.PI*2);x.fill();
    },
    (c,x)=>{
      x.clearRect(0,0,38,38);
      // Veilmark — concentric rings
      x.shadowColor='#f43f5e';x.shadowBlur=10;
      x.strokeStyle='#f43f5e';x.lineWidth=2;
      for(let r of[13,8,4]){x.globalAlpha=r/13;x.beginPath();x.arc(19,19,r,0,Math.PI*2);x.stroke();}
      x.globalAlpha=1;
      x.fillStyle='#f43f5e';x.beginPath();x.arc(19,19,3.5,0,Math.PI*2);x.fill();
      x.strokeStyle='#f43f5e88';x.lineWidth=1.5;
      x.beginPath();x.moveTo(19,3);x.lineTo(19,7);x.moveTo(19,31);x.lineTo(19,35);
      x.moveTo(3,19);x.lineTo(7,19);x.moveTo(31,19);x.lineTo(35,19);x.stroke();
    },
    (c,x)=>{
      x.clearRect(0,0,38,38);
      // Detonate — explosion star
      x.shadowColor='#ff6b35';x.shadowBlur=12;
      x.fillStyle='#ff6b35';
      for(let i=0;i<8;i++){
        const a=(i/8)*Math.PI*2,r1=14,r2=7;
        x.beginPath();x.moveTo(19+Math.cos(a)*r1,19+Math.sin(a)*r1);
        x.lineTo(19+Math.cos(a+Math.PI/8)*r2,19+Math.sin(a+Math.PI/8)*r2);
        x.lineTo(19+Math.cos(a+Math.PI/4)*r1,19+Math.sin(a+Math.PI/4)*r1);
        x.closePath();x.fill();
      }
      x.fillStyle='#fff8';x.beginPath();x.arc(19,19,4.5,0,Math.PI*2);x.fill();
    },
    (c,x)=>{
      x.clearRect(0,0,38,38);
      // Wrath tide — wave lines
      x.shadowColor='#a855f7';x.shadowBlur=10;
      x.strokeStyle='#a855f7';x.lineWidth=2.5;
      for(let i=0;i<4;i++){
        x.globalAlpha=1-i*0.2;x.beginPath();
        x.moveTo(4,12+i*4);x.quadraticCurveTo(19,5+i*4,34,12+i*4);x.stroke();
      }
      x.globalAlpha=1;
    },
  ];
  for(let i=0;i<4;i++){
    const c=document.getElementById('ic'+i);
    if(c)icons[i](c,c.getContext('2d'));
  }
}


// ═══════ GAME STATE ══════════════════════════════════════
let running=false,lastTime=0,kills=0;
let camX=WORLD_W/2,camY=WORLD_H/2;
let bossTarget=null;

let player={
  x:WORLD_W/2,y:WORLD_H/2,hp:1000,maxHp:1000,attack:15,
  level:1,xp:0,xpToNext:165,gold:0,
  vx:0,vy:0,facing:0,
  lastAttack:0,lastInput:0,
  isDead:false,iframes:0,
  soulMastery:0,glowPulse:0,hitFlash:0,walkCycle:0,
  afkWpX:WORLD_W/2,afkWpY:WORLD_H/2,
  afkTimer:0,afkCommit:5000,sector:0,
  visitedSectors:new Array(9).fill(false),
  maxBonds:MAX_SPIRITS,
};

let spirits=[],enemies=[],particles=[],dmgTexts=[],groundFX=[];
let spiritId=0,enemyId=0;
let abilityCDs=[0,0,0,0];
let spawnTimer=0;
let keys={},touchJoy={active:false,startX:0,startY:0,dx:0,dy:0},joyId=null;
let shakeTimer=0,shakeAmt=0;
let clusterTimer=0,clusterInterval=9000;
// Precomputed environment
let envProps=[];


// ═══════ ENVIRONMENT GENERATION ══════════════════════════
// Note: envProps is declared above in GAME STATE section
function rngF(s){return((s*16807)%2147483647)/2147483647;}
function generateEnvironment(){
  envProps=[];const z=curZone;let s=7919;
  z.props.forEach((type,ti)=>{
    const cnt=z.counts[ti]||30;
    for(let i=0;i<cnt;i++){
      s=(s*1013+i*31+ti*97)%99991+1;
      envProps.push({x:(rngF(s)*0.88+0.06)*WORLD_W,y:(rngF(s*3+7)*0.88+0.06)*WORLD_H,
        type,sz:16+rngF(s*5)*42,rot:rngF(s*7)*Math.PI*2,seed:s});
    }
  });
}

function drawEnvironment(now){
  const margin=320,vl=camX-W/2-margin,vr=camX+W/2+margin,vt=camY-H/2-margin,vb=camY+H/2+margin;
  envProps.forEach(p=>{if(p.x>vl&&p.x<vr&&p.y>vt&&p.y<vb)drawProp(p,now);});
}

function drawProp(p,now){
  const z=curZone,s=p.sz,seed=p.seed;
  ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rot);
  switch(p.type){
    case 'ashStone':
      ctx.fillStyle='#1a1030';ctx.strokeStyle='#2d1a50';ctx.lineWidth=1;
      ctx.beginPath();ctx.ellipse(0,0,s*.65,s*.38,0,0,Math.PI*2);ctx.fill();ctx.stroke();
      ctx.fillStyle='#110820';ctx.beginPath();ctx.ellipse(-s*.14,-s*.05,s*.32,s*.19,0.4,0,Math.PI*2);ctx.fill();break;
    case 'ashArch':
      ctx.shadowColor='#c084fc';ctx.shadowBlur=8;ctx.strokeStyle='#2d1a5a';ctx.lineWidth=3.5;
      ctx.beginPath();ctx.arc(0,8,s*.42,Math.PI,0);ctx.stroke();ctx.lineWidth=5;
      ctx.beginPath();ctx.moveTo(-s*.42,8);ctx.lineTo(-s*.42,s*.55);ctx.stroke();
      ctx.beginPath();ctx.moveTo(s*.42,8);ctx.lineTo(s*.42,s*.55);ctx.stroke();
      ctx.fillStyle='rgba(192,132,252,0.22)';ctx.shadowBlur=6;ctx.beginPath();ctx.arc(0,8-s*.42,4,0,Math.PI*2);ctx.fill();break;
    case 'veilCrystal':{
      const ch=curZone.id==='spire'?5:270;
      ctx.shadowColor='hsl('+ch+',80%,55%)';ctx.shadowBlur=12+Math.sin(now/700+seed)*5;
      ctx.strokeStyle='hsl('+ch+',70%,40%)';ctx.lineWidth=2.2;
      const pts=3+Math.floor(rngF(seed)*3);
      for(let i=0;i<pts;i++){const a=(i/pts)*Math.PI*2+p.rot*.5,h=s*(.4+rngF(seed+i)*.45);
        ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(Math.cos(a)*h,Math.sin(a)*h);ctx.stroke();
        ctx.fillStyle='hsla('+ch+',65%,55%,'+(0.38+Math.sin(now/500+seed+i)*.14)+')';
        ctx.beginPath();ctx.arc(Math.cos(a)*h,Math.sin(a)*h,3.5,0,Math.PI*2);ctx.fill();}
      ctx.globalAlpha=.35+Math.sin(now/550+seed)*.1;ctx.fillStyle='hsl('+ch+',70%,42%)';
      ctx.beginPath();ctx.arc(0,0,s*.12,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;break;}
    case 'darkPool':{
      const dp=ctx.createRadialGradient(0,0,0,0,0,s);dp.addColorStop(0,'rgba(15,0,40,0.72)');dp.addColorStop(.6,'rgba(8,0,25,0.45)');dp.addColorStop(1,'rgba(5,0,15,0)');
      ctx.fillStyle=dp;ctx.beginPath();ctx.ellipse(0,0,s,s*.42,0,0,Math.PI*2);ctx.fill();
      ctx.strokeStyle='rgba(120,60,220,'+(0.06+Math.sin(now/1300+seed)*.03)+')';ctx.lineWidth=.9;
      ctx.beginPath();ctx.ellipse(0,0,s*.65,s*.27,0,0,Math.PI*2);ctx.stroke();break;}
    case 'ashPatch':{
      const ap=ctx.createRadialGradient(0,0,0,0,0,s);ap.addColorStop(0,'rgba(40,25,70,0.28)');ap.addColorStop(1,'rgba(15,8,30,0)');
      ctx.fillStyle=ap;ctx.beginPath();ctx.ellipse(0,0,s,s*.5,0,0,Math.PI*2);ctx.fill();break;}
    case 'veilTorch':case 'cryptTorch':case 'hellTorch':{
      const tc=p.type==='hellTorch'?'rgba(255,60,10,':p.type==='veilTorch'?'rgba(200,100,30,':'rgba(220,150,40,';
      ctx.strokeStyle='#2a1a10';ctx.lineWidth=2.2;ctx.lineCap='round';
      ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,s*.62);ctx.stroke();
      const fp=.62+Math.sin(now/110+seed)*.32;ctx.shadowColor=tc+'1)';ctx.shadowBlur=22*fp;
      const fg=ctx.createRadialGradient(0,-s*.1,0,0,-s*.1,s*.26);
      fg.addColorStop(0,'rgba(255,250,200,.95)');fg.addColorStop(.35,tc+'.82)');fg.addColorStop(1,tc+'0)');
      ctx.fillStyle=fg;ctx.beginPath();ctx.ellipse(0,-s*.05,s*.11,s*.25*fp,0,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=.12+Math.sin(now/200+seed)*.06;ctx.fillStyle='#aaa';
      ctx.beginPath();ctx.ellipse(Math.sin(now/300+seed)*4,-s*.45,s*.06,s*.2,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;break;}
    case 'ruinWall':
      ctx.fillStyle='#140c2a';ctx.strokeStyle='#2a1545';ctx.lineWidth=1.5;
      ctx.fillRect(-s*.08,-s*.8,s*.16,s*1.6);ctx.strokeRect(-s*.08,-s*.8,s*.16,s*1.6);
      ctx.fillStyle='#0e0820';ctx.fillRect(-s*.12,-s*.85,s*.06,s*.12);ctx.fillRect(s*.04,-s*.82,s*.08,s*.1);break;
    case 'bonePile':
      ctx.strokeStyle='#3a3020';ctx.lineWidth=2;ctx.lineCap='round';
      for(let i=0;i<5;i++){const a=rngF(seed+i)*Math.PI*2,bl=s*(.2+rngF(seed+i*3)*.32);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(Math.cos(a)*bl,Math.sin(a)*bl);ctx.stroke();}
      ctx.fillStyle='#2a2218';ctx.beginPath();ctx.arc(0,0,s*.12,0,Math.PI*2);ctx.fill();break;
    case 'cryptPillar':
      ctx.fillStyle='#14100a';ctx.strokeStyle='#2a2010';ctx.lineWidth=1.5;
      ctx.fillRect(-s*.2,-s*.85,s*.4,s*1.7);ctx.strokeRect(-s*.2,-s*.85,s*.4,s*1.7);
      ctx.fillRect(-s*.28,-s*.88,s*.56,s*.14);ctx.fillRect(-s*.28,s*.74,s*.56,s*.14);
      ctx.strokeStyle='#1a1408';ctx.lineWidth=.8;
      for(let i=1;i<4;i++){ctx.beginPath();ctx.moveTo(-s*.2,-s*.85+s*i*.42);ctx.lineTo(s*.2,-s*.85+s*i*.42);ctx.stroke();}break;
    case 'sarcophagus':
      ctx.fillStyle='#18120a';ctx.strokeStyle='#2a1e10';ctx.lineWidth=1.5;
      ctx.beginPath();ctx.roundRect(-s*.32,-s*.62,s*.64,s*1.24,4);ctx.fill();ctx.stroke();
      ctx.strokeStyle='#32261a';ctx.lineWidth=1;ctx.beginPath();ctx.arc(0,-s*.22,s*.14,0,Math.PI*2);ctx.stroke();
      ctx.beginPath();ctx.moveTo(0,-s*.45);ctx.lineTo(0,s*.3);ctx.stroke();
      ctx.shadowColor='#d97706';ctx.shadowBlur=5;ctx.strokeStyle='rgba(217,119,6,0.18)';ctx.lineWidth=.8;
      ctx.beginPath();ctx.moveTo(-s*.05,-s*.3);ctx.lineTo(s*.08,s*.2);ctx.stroke();break;
    case 'cryptTomb':
      ctx.fillStyle='#14100c';ctx.strokeStyle='#221a10';ctx.lineWidth=1.5;
      ctx.fillRect(-s*.4,-s*.22,s*.8,s*.44);ctx.beginPath();ctx.arc(0,-s*.22,s*.4,Math.PI,0);ctx.fill();ctx.stroke();
      ctx.strokeStyle='rgba(217,119,6,0.15)';ctx.lineWidth=1;
      ctx.beginPath();ctx.moveTo(0,-s*.52);ctx.lineTo(0,s*.18);ctx.moveTo(-s*.18,-s*.12);ctx.lineTo(s*.18,-s*.12);ctx.stroke();break;
    case 'skullPile':
      for(let i=0;i<4;i++){const sx2=(-1.5+i)*s*.22,sy2=(i%2)*s*.1-s*.05;
        ctx.fillStyle='#2a2218';ctx.beginPath();ctx.arc(sx2,sy2,s*.16,0,Math.PI*2);ctx.fill();
        ctx.fillStyle='#0e0c08';ctx.beginPath();ctx.arc(sx2-s*.05,sy2-s*.04,s*.04,0,Math.PI*2);ctx.fill();
        ctx.beginPath();ctx.arc(sx2+s*.05,sy2-s*.04,s*.04,0,Math.PI*2);ctx.fill();}break;
    case 'cobweb':
      ctx.strokeStyle='rgba(200,200,210,0.1)';ctx.lineWidth=.7;
      for(let i=0;i<8;i++){const a=(i/8)*Math.PI*2;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(Math.cos(a)*s*.5,Math.sin(a)*s*.5);ctx.stroke();}
      for(let r=1;r<=3;r++){ctx.beginPath();for(let i=0;i<8;i++){const a=(i/8)*Math.PI*2;i===0?ctx.moveTo(Math.cos(a)*s*(r*.15),Math.sin(a)*s*(r*.15)):ctx.lineTo(Math.cos(a)*s*(r*.15),Math.sin(a)*s*(r*.15));}ctx.closePath();ctx.stroke();}break;
    case 'cryptWall':
      ctx.fillStyle='#100c08';ctx.strokeStyle='#1e1810';ctx.lineWidth=1;
      ctx.fillRect(-s*.06,-s*.7,s*.12,s*1.4);ctx.strokeRect(-s*.06,-s*.7,s*.12,s*1.4);
      for(let i=0;i<5;i++){ctx.beginPath();ctx.moveTo(-s*.06,-s*.7+i*s*.28);ctx.lineTo(s*.06,-s*.7+i*s*.28);ctx.stroke();}break;
    case 'swampTree':
      ctx.strokeStyle='#0a1808';ctx.lineWidth=3.5;ctx.lineCap='round';
      ctx.beginPath();ctx.moveTo(0,0);ctx.bezierCurveTo(s*.1,-s*.3,-s*.1,-s*.6,0,-s*.85);ctx.stroke();
      ctx.lineWidth=2;
      for(let i=0;i<6;i++){const a=(rngF(seed+i)-.4)*Math.PI*.75,bl=s*(.18+rngF(seed+i*2)*.28),by=-s*(.3+i*.1);
        ctx.beginPath();ctx.moveTo(0,by);ctx.lineTo(Math.cos(a)*bl,by+Math.sin(a)*bl*.5);ctx.stroke();}
      ctx.strokeStyle='rgba(50,120,60,0.22)';ctx.lineWidth=1;
      for(let i=0;i<4;i++){const mx=(rngF(seed+i*5)-.5)*s*.4,my=-s*(.4+rngF(seed+i*3)*.3);ctx.beginPath();ctx.moveTo(mx,my);ctx.lineTo(mx+Math.sin(now/800+i)*3,my+s*.25);ctx.stroke();}break;
    case 'toxicPool':{
      const tp=ctx.createRadialGradient(0,0,0,0,0,s);tp.addColorStop(0,'rgba(20,80,30,0.75)');tp.addColorStop(.5,'rgba(10,50,18,0.5)');tp.addColorStop(1,'rgba(5,30,10,0)');
      ctx.fillStyle=tp;ctx.beginPath();ctx.ellipse(0,0,s,s*.42,0,0,Math.PI*2);ctx.fill();
      ctx.shadowColor='#34d399';ctx.shadowBlur=8+Math.sin(now/1000+seed)*3;
      ctx.strokeStyle='rgba(52,211,153,'+(0.08+Math.sin(now/1100+seed)*.04)+')';ctx.lineWidth=1;
      ctx.beginPath();ctx.ellipse(0,0,s*.68,s*.28,0,0,Math.PI*2);ctx.stroke();break;}
    case 'mushroom':
      ctx.strokeStyle='#0a1808';ctx.lineWidth=1.8;ctx.lineCap='round';
      ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,s*.55);ctx.stroke();
      ctx.fillStyle='hsl('+(145+rngF(seed)*35)+',45%,'+(18+rngF(seed*2)*12)+'%)';ctx.shadowColor='#34d399';ctx.shadowBlur=7;
      ctx.beginPath();ctx.ellipse(0,s*.54,s*.38,s*.22,0,0,Math.PI,true);ctx.fill();
      ctx.fillStyle='rgba(52,211,153,0.18)';ctx.beginPath();ctx.ellipse(0,s*.52,s*.26,s*.14,0,0,Math.PI,true);ctx.fill();
      ctx.fillStyle='rgba(52,211,153,0.35)';
      for(let i=0;i<3;i++){ctx.beginPath();ctx.arc((rngF(seed+i)-.5)*s*.3,s*.48,2,0,Math.PI*2);ctx.fill();}break;
    case 'mireRoot':
      ctx.strokeStyle='#0a1005';ctx.lineWidth=2.5;ctx.lineCap='round';
      for(let i=0;i<3;i++){const a=rngF(seed+i)*Math.PI,bl=s*(.28+rngF(seed+i*4)*.32);
        ctx.beginPath();ctx.moveTo(0,0);ctx.bezierCurveTo(Math.cos(a)*bl*.4,Math.sin(a)*bl*.3+s*.1,Math.cos(a)*bl*.8,Math.sin(a)*bl*.6+s*.1,Math.cos(a)*bl,Math.sin(a)*bl*.5+s*.1);ctx.stroke();}break;
    case 'toxicVent':{
      ctx.fillStyle='#080e06';ctx.beginPath();ctx.arc(0,0,s*.22,0,Math.PI*2);ctx.fill();
      const tv=.5+Math.sin(now/260+seed)*.5;ctx.globalAlpha=tv*.62;ctx.fillStyle='#34d399';ctx.shadowColor='#34d399';ctx.shadowBlur=14;
      ctx.beginPath();ctx.ellipse(Math.sin(now/180+seed)*4,-s*.18,s*.12,s*.32,0,0,Math.PI*2);ctx.fill();
      ctx.globalAlpha=tv*.32;ctx.beginPath();ctx.ellipse(Math.sin(now/250+seed)*6,-s*.38,s*.08,s*.22,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;break;}
    case 'mireVine':
      ctx.strokeStyle='rgba(40,90,30,0.38)';ctx.lineWidth=1.5;ctx.lineCap='round';
      for(let i=0;i<4;i++){const a=(i/4)*Math.PI*2;ctx.beginPath();ctx.moveTo(0,0);ctx.bezierCurveTo(Math.cos(a)*s*.3+Math.sin(now/600+i)*5,Math.sin(a)*s*.3,Math.cos(a)*s*.6,Math.sin(a)*s*.6);ctx.stroke();}break;
    case 'swampRock':
      ctx.fillStyle='#080e06';ctx.strokeStyle='#0e1a0a';ctx.lineWidth=1;
      ctx.beginPath();ctx.ellipse(0,0,s*.58,s*.34,0,0,Math.PI*2);ctx.fill();ctx.stroke();
      ctx.fillStyle='rgba(52,211,153,0.055)';ctx.beginPath();ctx.ellipse(-s*.1,s*.05,s*.18,s*.1,0.4,0,Math.PI*2);ctx.fill();break;
    case 'lavaPool':{
      const lv=ctx.createRadialGradient(0,0,0,0,0,s);lv.addColorStop(0,'rgba(255,80,0,0.8)');lv.addColorStop(.4,'rgba(180,40,0,0.55)');lv.addColorStop(1,'rgba(60,10,0,0)');
      ctx.fillStyle=lv;ctx.beginPath();ctx.ellipse(0,0,s,s*.42,0,0,Math.PI*2);ctx.fill();
      ctx.shadowColor='#ff5500';ctx.shadowBlur=18+Math.sin(now/600+seed)*6;
      ctx.strokeStyle='rgba(255,120,0,'+(0.12+Math.sin(now/800+seed)*.06)+')';ctx.lineWidth=1.2;
      ctx.beginPath();ctx.ellipse(0,0,s*.6,s*.25,0,0,Math.PI*2);ctx.stroke();break;}
    case 'obsidianPillar':
      ctx.fillStyle='#120002';ctx.strokeStyle='rgba(255,60,60,0.2)';ctx.lineWidth=1;
      ctx.beginPath();ctx.moveTo(-s*.16,-s*.95);ctx.lineTo(s*.16,-s*.95);ctx.lineTo(s*.22,s*.32);ctx.lineTo(-s*.22,s*.32);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.shadowColor='#ff4444';ctx.shadowBlur=10;ctx.strokeStyle='rgba(255,80,80,0.35)';ctx.lineWidth=.9;
      ctx.beginPath();ctx.moveTo(-s*.06,-s*.78);ctx.lineTo(s*.08,s*.18);ctx.stroke();break;
    case 'veilRift':{
      const rp=.38+Math.sin(now/360+seed)*.22;ctx.globalAlpha=rp;ctx.strokeStyle='rgba(255,80,80,0.7)';ctx.lineWidth=2;ctx.shadowColor='#ff4444';ctx.shadowBlur=14;
      ctx.beginPath();ctx.moveTo(-s*.55,0);ctx.bezierCurveTo(-s*.2,-s*.22,s*.2,s*.22,s*.55,0);ctx.stroke();
      ctx.globalAlpha=rp*.6;ctx.fillStyle='rgba(255,60,60,0.12)';ctx.beginPath();ctx.ellipse(0,0,s*.45,s*.14,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;break;}
    case 'ashObelisk':
      ctx.fillStyle='#150003';ctx.strokeStyle='rgba(200,30,30,0.15)';ctx.lineWidth=1.5;
      ctx.beginPath();ctx.moveTo(0,-s*.95);ctx.lineTo(s*.14,-s*.2);ctx.lineTo(s*.2,s*.3);ctx.lineTo(-s*.2,s*.3);ctx.lineTo(-s*.14,-s*.2);ctx.closePath();ctx.fill();ctx.stroke();
      ctx.fillStyle='rgba(255,60,60,0.12)';ctx.shadowColor='#ff4444';ctx.shadowBlur=8;
      ctx.beginPath();ctx.arc(0,-s*.7,4,0,Math.PI*2);ctx.fill();break;
    case 'crackGround':
      ctx.strokeStyle='rgba(255,50,50,0.18)';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(-s*.5,0);
      for(let i=1;i<8;i++){ctx.lineTo(-s*.5+i*s*.14,(rngF(seed+i)-.5)*s*.18);}
      ctx.lineTo(s*.5,0);ctx.stroke();
      ctx.globalAlpha=.2;ctx.strokeStyle='rgba(255,100,0,0.4)';ctx.lineWidth=.6;
      ctx.beginPath();ctx.moveTo(-s*.35,s*.06);ctx.lineTo(s*.35,-s*.06);ctx.stroke();ctx.globalAlpha=1;break;
  }
  ctx.restore();
}


// ═══════ PLAYER DRAW ════════════════════════════════════
function drawPlayer(t){
  const p=player;
  if(p.isDead)return;
  const fl=p.hitFlash>0;
  const glow=0.8+Math.sin(p.glowPulse)*0.2;
  const spCount=spirits.filter(s=>!s.dead).length;
  p.walkCycle+=(Math.abs(p.vx)+Math.abs(p.vy))>5?0.15:0;

  ctx.save();
  const flipX=Math.cos(p.facing)<0;
  ctx.translate(p.x,p.y);
  if(flipX)ctx.scale(-1,1);

  // Aura under player
  const auraR=30+spCount*5;
  const aura=ctx.createRadialGradient(0,15,0,0,15,auraR);
  aura.addColorStop(0,`rgba(157,196,176,${0.08+spCount*0.012})`);
  aura.addColorStop(1,'rgba(157,196,176,0)');
  ctx.fillStyle=aura;ctx.beginPath();ctx.ellipse(0,18,auraR,auraR*0.4,0,0,Math.PI*2);ctx.fill();

  ctx.shadowColor=fl?'#ff4444':'#9DC4B0';
  ctx.shadowBlur=fl?20:(12+spCount*3)*glow;

  // Robe body
  ctx.fillStyle=fl?'#ffaaaa':'#1a1235';
  ctx.beginPath();ctx.ellipse(0,4,10,15,0,0,Math.PI*2);ctx.fill();
  // Robe bottom (flowing)
  ctx.fillStyle=fl?'#ffaaaa':'#110c28';
  ctx.beginPath();ctx.moveTo(-10,7);ctx.bezierCurveTo(-14,17,-9,24,-4,23);ctx.bezierCurveTo(-1,28,1,28,4,23);ctx.bezierCurveTo(9,24,14,17,10,7);ctx.closePath();ctx.fill();
  // Robe arcane trim
  ctx.strokeStyle=fl?'#fff':`rgba(192,132,252,${0.3+glow*0.25})`;ctx.lineWidth=1;
  ctx.beginPath();ctx.moveTo(-10,7);ctx.bezierCurveTo(-14,17,-9,24,-4,23);ctx.bezierCurveTo(-1,28,1,28,4,23);ctx.bezierCurveTo(9,24,14,17,10,7);ctx.stroke();
  // Chest rune
  ctx.fillStyle=fl?'#fff':'rgba(192,132,252,0.5)';ctx.shadowColor='#c084fc';ctx.shadowBlur=8;
  ctx.beginPath();ctx.arc(0,1,3,0,Math.PI*2);ctx.fill();

  // Left arm
  const armSwing=Math.sin(p.walkCycle)*7;
  ctx.strokeStyle=fl?'#ffaaaa':'#2d2060';ctx.lineWidth=5;ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(-7,0);ctx.lineTo(-11-armSwing*0.6,10);ctx.stroke();
  // Right arm + staff
  ctx.beginPath();ctx.moveTo(7,0);ctx.lineTo(12+armSwing,11);ctx.stroke();
  // Staff shaft
  ctx.strokeStyle=fl?'#fff':'#9DC4B0';ctx.lineWidth=2;ctx.lineCap='square';
  ctx.beginPath();ctx.moveTo(12+armSwing,11);ctx.lineTo(17+armSwing,-10);ctx.stroke();
  // Staff head
  ctx.strokeStyle=fl?'#fff':'#c084fc';ctx.lineWidth=2;ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(14+armSwing,-10);ctx.lineTo(20+armSwing,-10);ctx.stroke();
  ctx.beginPath();ctx.moveTo(17+armSwing,-13);ctx.lineTo(17+armSwing,-7);ctx.stroke();
  // Staff orb
  const orbPulse=0.42+Math.sin(t/380)*0.18;
  ctx.fillStyle='#c084fc';ctx.shadowColor='#c084fc';ctx.shadowBlur=16;
  ctx.beginPath();ctx.arc(17+armSwing,-10,4.5,0,Math.PI*2);ctx.fill();
  ctx.globalAlpha=orbPulse;ctx.fillStyle='#e9d5ff';
  ctx.beginPath();ctx.arc(17+armSwing,-10,8,0,Math.PI*2);ctx.fill();
  ctx.globalAlpha=1;

  // Head/hood
  ctx.shadowColor=fl?'#ff4444':'#c084fc';ctx.shadowBlur=10;
  ctx.fillStyle=fl?'#ffaaaa':'#1a1235';
  ctx.beginPath();ctx.arc(0,-12,10,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=fl?'#ffaaaa':'#0d0820';
  ctx.beginPath();ctx.moveTo(-11,-12);ctx.lineTo(0,-30);ctx.lineTo(11,-12);ctx.closePath();ctx.fill();
  ctx.fillStyle='rgba(0,0,0,0.4)';
  ctx.beginPath();ctx.ellipse(0,-12,8,5,0,0,Math.PI);ctx.fill();
  // Eyes
  ctx.fillStyle=fl?'#ff4444':'#9DC4B0';ctx.shadowColor='#9DC4B0';ctx.shadowBlur=10;
  ctx.beginPath();ctx.arc(-3.5,-13,2.2,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(3.5,-13,2.2,0,Math.PI*2);ctx.fill();

  ctx.restore();

  // Movement robe particles
  if(Math.abs(p.vx)+Math.abs(p.vy)>8&&Math.random()<0.1){
    particles.push({x:p.x+(Math.random()-0.5)*10,y:p.y+20,vx:(Math.random()-0.5)*25,vy:12+Math.random()*18,life:0.55,maxLife:0.55,color:'rgba(192,132,252,0.35)',size:2+Math.random()*2});
  }
}

// ═══════ SPIRIT DRAW ════════════════════════════════════
function drawSpirit(s,t){
  if(s.dead)return;
  const pulse=0.8+Math.sin(t/700+s.id)*0.2;
  ctx.save();
  ctx.globalAlpha=0.93*pulse;
  ctx.shadowColor='#9DC4B0';ctx.shadowBlur=18;
  if(!isFinite(s.x)||!isFinite(s.y)){ctx.restore();return;}
  // Glow core
  const g=ctx.createRadialGradient(s.x,s.y,0,s.x,s.y,16);
  g.addColorStop(0,'#ffffff');g.addColorStop(0.35,'#9DC4B0');g.addColorStop(1,'rgba(157,196,176,0)');
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(s.x,s.y,16,0,Math.PI*2);ctx.fill();
  // Ghost body
  ctx.fillStyle='rgba(157,196,176,0.75)';
  ctx.beginPath();ctx.arc(s.x,s.y-6,7,Math.PI,0);ctx.lineTo(s.x+7,s.y+2);
  for(let i=0;i<3;i++)ctx.arc(s.x+5-i*4.5,s.y+2,2,0,Math.PI,true);
  ctx.lineTo(s.x-7,s.y+2);ctx.closePath();ctx.fill();
  // Wisp tail
  ctx.fillStyle='rgba(157,196,176,0.4)';
  ctx.beginPath();ctx.moveTo(s.x-5,s.y+7);
  ctx.bezierCurveTo(s.x-3,s.y+14+Math.sin(t/280+s.id)*4,s.x+3,s.y+14-Math.sin(t/280+s.id)*4,s.x+5,s.y+7);
  ctx.closePath();ctx.fill();
  // Eyes
  ctx.fillStyle='rgba(0,0,0,0.7)';ctx.shadowBlur=0;
  ctx.beginPath();ctx.arc(s.x-2.5,s.y-7,2.8,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(s.x+2.5,s.y-7,2.8,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#fff';
  ctx.beginPath();ctx.arc(s.x-2.5,s.y-7,1.1,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(s.x+2.5,s.y-7,1.1,0,Math.PI*2);ctx.fill();
  ctx.restore();
}

// ═══════ BACKGROUND & FOG ═══════════════════════════════
function drawBackground(now){}// kept for compat
function drawGroundPlane(now){}// kept for compat

function drawWorld(now){
  const z=curZone;
  // Zone-specific sky gradient
  const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,z.skyA);sky.addColorStop(.5,z.skyB);sky.addColorStop(1,z.skyC);
  ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
  ctx.save();ctx.translate(W/2-camX,H/2-camY);
  // Ground
  ctx.fillStyle=z.groundBase;ctx.fillRect(0,0,WORLD_W,WORLD_H);
  // Tile texture
  const gs=68,sl=camX-W/2,sr=camX+W/2,st=camY-H/2,sb=camY+H/2;
  for(let gx=Math.floor(sl/gs)*gs;gx<sr+gs;gx+=gs){
    for(let gy=Math.floor(st/gs)*gs;gy<sb+gs;gy+=gs){
      ctx.fillStyle=(Math.floor(gx/gs)+Math.floor(gy/gs))%2?z.tileA:z.tileB;ctx.fillRect(gx,gy,gs,gs);
    }
  }
  ctx.strokeStyle=z.gridC;ctx.lineWidth=.5;
  for(let gx=Math.floor(sl/gs)*gs;gx<sr+gs;gx+=gs){ctx.beginPath();ctx.moveTo(gx,st);ctx.lineTo(gx,sb);ctx.stroke();}
  for(let gy=Math.floor(st/gs)*gs;gy<sb+gs;gy+=gs){ctx.beginPath();ctx.moveTo(sl,gy);ctx.lineTo(sr,gy);ctx.stroke();}
  // Light pillars
  if(z.hasPillars){
    for(let i=0;i<5;i++){
      const lx=((camX/WORLD_W+i*.18)*WORLD_W)%WORLD_W;const ly=((camY/WORLD_H+i*.25)*WORLD_H)%WORLD_H;
      const lr=178+Math.sin(now/2800+i)*55;
      const lg=ctx.createRadialGradient(lx,ly,0,lx,ly,lr);
      lg.addColorStop(0,z.lightC+'.055)');lg.addColorStop(1,z.lightC+'0)');
      ctx.fillStyle=lg;ctx.beginPath();ctx.arc(lx,ly,lr,0,Math.PI*2);ctx.fill();
    }
  }
  // Animated fog
  for(let i=0;i<6;i++){
    const fx=((now/5200+i*.19)*WORLD_W)%WORLD_W-WORLD_W*.12;
    const fy=camY-H*.22+Math.sin(now/6500+i*1.4)*H*.18;
    const fw=W*(.52+Math.sin(now/5500+i)*.16);
    const fg=ctx.createRadialGradient(fx,fy,0,fx,fy,fw);
    fg.addColorStop(0,z.fogC+(.04+Math.sin(now/2200+i)*.022)+')');fg.addColorStop(1,z.fogC+'0)');
    ctx.fillStyle=fg;ctx.beginPath();ctx.ellipse(fx,fy,fw,fw*.28,0,0,Math.PI*2);ctx.fill();
  }
  // Zone ambient FX
  if(z.ashFx){for(let i=0;i<8;i++){ctx.globalAlpha=.14+Math.sin(now/1500+i)*.07;ctx.fillStyle='rgba(200,150,255,0.5)';ctx.beginPath();ctx.arc((camX+Math.sin(now/4000+i*1.7)*(W*.4)+WORLD_W)%WORLD_W,(camY-H*.3+Math.sin(now/3500+i)*(H*.4)+WORLD_H)%WORLD_H,1.2+Math.sin(now/800+i)*.5,0,Math.PI*2);ctx.fill();}ctx.globalAlpha=1;}
  if(z.lavaFx){for(let i=0;i<4;i++){ctx.globalAlpha=(.5+Math.sin(now/300+i)*.3)*.055;const hg=ctx.createRadialGradient((camX+(-2+i)*W*.28+WORLD_W)%WORLD_W,camY+H*.3,0,(camX+(-2+i)*W*.28+WORLD_W)%WORLD_W,camY+H*.3,150);hg.addColorStop(0,'rgba(255,80,0,0.5)');hg.addColorStop(1,'rgba(255,80,0,0)');ctx.fillStyle=hg;ctx.beginPath();ctx.arc((camX+(-2+i)*W*.28+WORLD_W)%WORLD_W,camY+H*.3,150,0,Math.PI*2);ctx.fill();}ctx.globalAlpha=1;}
  if(z.toxicFx){for(let i=0;i<6;i++){ctx.globalAlpha=.2+Math.sin(now/600+i)*.1;ctx.fillStyle='rgba(52,211,153,0.5)';ctx.beginPath();ctx.arc((camX+(i-.5)*W*.3+WORLD_W)%WORLD_W,((camY+H*.3-((now/2000+i)%1)*H*.8)+WORLD_H)%WORLD_H,2+Math.sin(now/400+i),0,Math.PI*2);ctx.fill();}ctx.globalAlpha=1;}
  // Edge vignette
  const ev=ctx.createRadialGradient(WORLD_W/2,WORLD_H/2,WORLD_W*.32,WORLD_W/2,WORLD_H/2,WORLD_W*.76);ev.addColorStop(0,'rgba(0,0,0,0)');ev.addColorStop(1,z.edgeC);ctx.fillStyle=ev;ctx.fillRect(0,0,WORLD_W,WORLD_H);
  // Props
  drawEnvironment(now);
  ctx.restore();
}

// ═══════ SPAWN SYSTEMS ══════════════════════════════════
function spawnEnemy(typeOverride=null){
  const living=enemies.filter(e=>!e.dead).length;
  if(living>=MAX_ENEMIES)return;
  const angle=Math.random()*Math.PI*2;
  const d=300+Math.random()*260;
  const x=Math.max(60,Math.min(WORLD_W-60,player.x+Math.cos(angle)*d));
  const y=Math.max(60,Math.min(WORLD_H-60,player.y+Math.sin(angle)*d));
  let typeData;
  if(typeOverride)typeData=ENEMY_TYPES.find(t=>t.type===typeOverride)||ENEMY_TYPES[0];
  else{
    const bias=curZone.bias||[];
    if(Math.random()<0.55&&bias.length){const t=bias[Math.floor(Math.random()*bias.length)];typeData=ENEMY_TYPES.find(e=>e.type===t);}
    if(!typeData){const pool=ENEMY_TYPES.filter(t=>!t.elite||(player.level>=8&&Math.random()<0.12));typeData=pool[Math.floor(Math.random()*pool.length)];}
  }
  const isElite=player.level>=5&&Math.random()<0.08;
  const hs=enemyHpScale(player.level),ds=enemyDmgScale(player.level);
  const base=player.level<=5?150:player.level<=10?175:200;
  enemies.push({
    id:enemyId++,x,y,vx:0,vy:0,
    hp:base*hs*typeData.hp*(isElite?2.4:1),
    maxHp:base*hs*typeData.hp*(isElite?2.4:1),
    attack:(player.level<=5?22:player.level<=10?26:30)*ds*typeData.dmg*(isElite?1.6:1),
    speed:typeData.spd*(isElite?1.12:1),
    dead:false,isElite,typeData,
    lastAttack:0,hitFlash:0,
    veilmarkStacks:0,veilmarkExpiry:0,
    size:typeData.r*(isElite?1.35:1),
  });
}
function spawnCluster(){
  const clusters=[{type:'skeleton',count:4},{type:'crawler',count:5},{type:'wraith',count:3},{type:'shade',count:4},{type:'golem',count:2},{type:'abomination',count:1}];
  const cl=clusters[Math.floor(Math.random()*clusters.length)];
  for(let i=0;i<cl.count;i++)setTimeout(()=>spawnEnemy(cl.type),i*220);
  addFeed(`☠ ${cl.type.toUpperCase()} HORDE!`,'#ef4444');
}
function spawnSpirit(isTemp=false){
  const perms=spirits.filter(s=>!s.isTemp&&!s.dead);
  if(!isTemp&&perms.length>=(player.maxBonds||MAX_SPIRITS))return false;
  const a=Math.random()*Math.PI*2;
  spirits.push({id:spiritId++,x:player.x+Math.cos(a)*40,y:player.y+Math.sin(a)*40,dead:false,isTemp,lifetime:isTemp?45000:Infinity,lastAttack:0,orbitAngle:Math.random()*Math.PI*2,hauntTarget:null,attackCount:0,wobble:Math.random()*Math.PI*2,empoweredUntil:0});
  return true;
}

// ═══════ AFK PATHFINDING ════════════════════════════════
function setAfkWaypoint(){
  player.afkTimer=0;
  let next=-1;
  for(let i=0;i<9;i++){const c=(player.sector+i+1)%9;if(!player.visitedSectors[c]){next=c;break;}}
  if(next===-1){player.visitedSectors.fill(false);next=Math.floor(Math.random()*9);}
  player.sector=next;
  const col=next%3,row=Math.floor(next/3),sw=WORLD_W/3,sh=WORLD_H/3;
  player.afkWpX=col*sw+100+Math.random()*(sw-200);
  player.afkWpY=row*sh+100+Math.random()*(sh-200);
}

// ═══════ ABILITY CASTS ══════════════════════════════════
function playerCast(idx){
  const now=performance.now();
  if(now<abilityCDs[idx]||player.isDead)return;
  if(idx===0){
    if(spawnSpirit()){abilityCDs[0]=now+ABILITY_CDS[0];SFX.spiritSummon();addFeed('✦ SPIRIT RAISED','#9DC4B0');emitSpiritBurst(player.x,player.y);}
  } else if(idx===1){
    const t=getNearestEnemy(950);
    if(t){t.veilmarkStacks=Math.min(t.veilmarkStacks+1,10);t.veilmarkExpiry=now+8000;abilityCDs[1]=now+ABILITY_CDS[1];SFX.veilmark();addFeed(`VEILMARK ×${t.veilmarkStacks}`,'#f43f5e');}
  } else if(idx===2){
    const t=getNearestMarkedEnemy();
    if(t&&t.veilmarkStacks>=3){
      const dmg=player.attack*2*t.veilmarkStacks;let hits=0;
      enemies.forEach(e=>{if(!e.dead&&dist2(t.x,t.y,e.x,e.y)<240){hitEnemy(e,dmg);hits++;}});
      t.veilmarkStacks=0;abilityCDs[2]=now+ABILITY_CDS[2];SFX.detonate();
      screenShake(12,280);emitExplosion(t.x,t.y,'#ff6b35');
      addFeed(`💥 DETONATE! ${hits} HIT · ${Math.round(dmg)}`,'#ff6b35');
    }
  } else if(idx===3){
    let hits=0;const dmg=player.attack*1.6;
    enemies.forEach(e=>{if(!e.dead&&dist2(player.x,player.y,e.x,e.y)<340){hitEnemy(e,dmg);e.veilmarkStacks=Math.min(e.veilmarkStacks+1,10);e.veilmarkExpiry=now+8000;hits++;}});
    abilityCDs[3]=now+ABILITY_CDS[3];SFX.wrathTide();
    emitWave(player.x,player.y);
    addFeed(`⚡ WRATH TIDE — ${hits} MARKED`,'#a855f7');
  }
}

// ═══════ COMBAT ═════════════════════════════════════════
function getNearestEnemy(maxR=Infinity){let b=null,bd=maxR;enemies.forEach(e=>{if(e.dead)return;const d=dist2(player.x,player.y,e.x,e.y);if(d<bd){bd=d;b=e;}});return b;}
function getNearestMarkedEnemy(){const now=performance.now();let b=null,bd=Infinity;enemies.forEach(e=>{if(e.dead||e.veilmarkStacks<=0||now>e.veilmarkExpiry)return;const d=dist2(player.x,player.y,e.x,e.y);if(d<bd){bd=d;b=e;}});return b;}

function hitEnemy(e,dmg,isCrit=false){
  if(e.dead)return;
  const critRoll=Math.random()<0.12;
  const finalDmg=critRoll?dmg*2.2:dmg;
  e.hp-=finalDmg;e.hitFlash=0.18;
  spawnDmgText(e.x,e.y-e.size,Math.round(finalDmg),critRoll?'#fde68a':'#fff',critRoll);
  for(let i=0;i<6;i++)particles.push({x:e.x,y:e.y,vx:(Math.random()-0.5)*180,vy:(Math.random()-0.5)*180,life:0.38,maxLife:0.38,color:e.typeData?.color||'#ef4444',size:2.5+Math.random()*3});
  if(e.hp<=0)killEnemy(e);
}

function killEnemy(e){
  e.dead=true;kills++;
  document.getElementById('killCount').textContent=`☠ ${kills}`;
  const xpG=e.isElite?60:14,goldG=e.isElite?30:6;
  addXP(xpG);player.gold+=goldG;
  SFX[e.isElite?'eliteDeath':'enemyDeath']();
  spawnDmgText(e.x,e.y-40,`+${xpG}XP`,'#8b5cf6',false);
  // Materials
  if(Math.random()<0.09){professions.Spiritweaving.materials.soulWisps++;addProfXP('Spiritweaving',2);addFeed('+Soul Wisp','#9DC4B048');}
  if(e.isElite&&Math.random()<0.28){professions.Spiritweaving.materials.veilCloth++;addProfXP('Spiritweaving',6);}
  if(e.isElite){professions.Veilstalking.materials.predatorMarks++;addProfXP('Veilstalking',14);}
  if(e.isElite&&Math.random()<0.18){professions.Veilstalking.materials.trophyShards++;}
  if(Math.random()<0.05){professions.Veilscribing.materials.veilDust++;addProfXP('Veilscribing',1);}
  if(e.veilmarkStacks>0&&Math.random()<0.14){professions.Spiritweaving.materials.paleEssence++;addProfXP('Spiritweaving',5);}
  // Loot
  if(Math.random()<(e.isElite?0.38:0.07)){const item=rollLoot(player.level);tryEquip(item);SFX.pickup();}
  // Death burst
  for(let i=0;i<14;i++){const a=Math.random()*Math.PI*2;particles.push({x:e.x,y:e.y,vx:Math.cos(a)*90,vy:Math.sin(a)*90-60,life:1.0,maxLife:1.0,color:e.typeData.color,size:3+Math.random()*4,soul:true});}
  // Update boss bar if this was the target
  if(bossTarget===e)bossTarget=null;
}

function addXP(amt){
  player.xp+=amt;
  while(player.xp>=player.xpToNext&&player.level<MAX_LEVEL){
    player.xp-=player.xpToNext;player.level++;player.xpToNext=xpForLevel(player.level);
    player.maxHp=computeMaxHp(player.level);player.hp=Math.min(player.hp+player.maxHp*0.3,player.maxHp);
    player.attack=computeAttack(player.level)+player.soulMastery*0.5;
    SFX.levelUp();showLevelUp();checkZone();
    if(player.level%5===0){professions.Spiritweaving.materials.hollowShards++;addProfXP('Spiritweaving',10);}
  }
}

// ═══════ VFX ════════════════════════════════════════════
function emitExplosion(x,y,color){for(let i=0;i<22;i++){const a=(i/22)*Math.PI*2,s=180+Math.random()*120;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:0.65,maxLife:0.65,color,size:5+Math.random()*5});}}
function emitWave(x,y){for(let i=0;i<28;i++){const a=Math.random()*Math.PI*2,s=120+Math.random()*180;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:0.55,maxLife:0.55,color:'#a855f7',size:4+Math.random()*5});}}
function emitSpiritBurst(x,y){for(let i=0;i<16;i++){const a=(i/16)*Math.PI*2;particles.push({x,y,vx:Math.cos(a)*100,vy:Math.sin(a)*100,life:0.7,maxLife:0.7,color:'#9DC4B0',size:4+Math.random()*3,soul:true});}}
function spawnDmgText(wx,wy,val,color,isCrit){dmgTexts.push({wx,wy,val:isCrit?'CRIT '+String(val):String(val),color,isCrit,life:1.4,maxLife:1.4,vy:-70-Math.random()*25,vx:(Math.random()-0.5)*35});}
function screenShake(amt,ms){shakeAmt=Math.max(shakeAmt,amt);shakeTimer=Math.max(shakeTimer,ms);}
function addFeed(msg,color='#9DC4B0'){const l=document.getElementById('feedLog');const el=document.createElement('div');el.className='feed';el.style.color=color;el.textContent=msg;l.prepend(el);setTimeout(()=>el.remove(),3800);}
function showLevelUp(){
  const unlocks={3:'Shop Unlocked',5:'Talents + Dungeons',8:'Soul Fissure',10:'Echoing Dirge',15:'Pale Eruption',20:'Veil Rupture'};
  document.getElementById('lvlUpTxt').textContent=`LEVEL ${player.level}`;
  document.getElementById('lvlUpUnlock').textContent=unlocks[player.level]||'Power Grows';
  const b=document.getElementById('lvlUpBanner');b.style.display='flex';
  setTimeout(()=>b.style.display='none',2600);
  addFeed(`✦ LEVEL ${player.level} ✦`,'#c084fc');
}
function respawn(){player.hp=player.maxHp;player.isDead=false;player.iframes=3000;player.x=WORLD_W/2;player.y=WORLD_H/2;enemies=[];spirits=[];document.getElementById('deathScreen').style.display='none';addFeed('RISEN FROM THE VEIL','#9DC4B0');}

// ═══════ UPDATE ═════════════════════════════════════════
function update(dt,now){
  if(player.isDead)return;
  let ix=0,iy=0;
  if(keys['ArrowLeft']||keys['a']||keys['A'])ix=-1;
  if(keys['ArrowRight']||keys['d']||keys['D'])ix=1;
  if(keys['ArrowUp']||keys['w']||keys['W'])iy=-1;
  if(keys['ArrowDown']||keys['s']||keys['S'])iy=1;
  if(keys['q']||keys['Q'])playerCast(0);
  if(keys['e']||keys['E'])playerCast(2);
  if(keys['r']||keys['R'])playerCast(3);
  if(touchJoy.active){ix=touchJoy.dx;iy=touchJoy.dy;}
  if(ix!==0||iy!==0)player.lastInput=now;
  const isAfk=now-player.lastInput>AFK_IDLE;

  if(ix!==0||iy!==0){
    const m=Math.sqrt(ix*ix+iy*iy)||1;
    player.vx=(ix/m)*PLAYER_SPEED;player.vy=(iy/m)*PLAYER_SPEED;
    player.facing=Math.atan2(iy,ix);
  } else if(isAfk){
    player.afkTimer+=dt*1000;
    const tx=player.afkWpX-player.x,ty=player.afkWpY-player.y,d=Math.sqrt(tx*tx+ty*ty)||1;
    const ne=getNearestEnemy(320);
    let mx=tx,my=ty,md=d;
    if(ne){mx=ne.x-player.x;my=ne.y-player.y;md=Math.sqrt(mx*mx+my*my)||1;}
    if(d<80||player.afkTimer>player.afkCommit){player.visitedSectors[player.sector]=true;setAfkWaypoint();}
    const spd=ne&&md<320?PLAYER_SPEED*0.9:PLAYER_SPEED*0.72;
    player.vx=(mx/md)*spd;player.vy=(my/md)*spd;
    player.facing=Math.atan2(my,mx);
  } else{player.vx*=0.78;player.vy*=0.78;}

  player.x=Math.max(30,Math.min(WORLD_W-30,player.x+player.vx*dt));
  player.y=Math.max(30,Math.min(WORLD_H-30,player.y+player.vy*dt));
  player.glowPulse+=dt*2.2;
  if(player.iframes>0)player.iframes-=dt*1000;
  if(player.hitFlash>0)player.hitFlash-=dt;

  // Auto attack
  if(now-player.lastAttack>ATTACK_CD){
    const t=getNearestEnemy(ATTACK_RANGE);
    if(t){player.lastAttack=now;hitEnemy(t,player.attack);SFX.hit();
      // Attack arc particles
      const dx=t.x-player.x,dy=t.y-player.y,d=Math.sqrt(dx*dx+dy*dy)||1;
      for(let i=0;i<4;i++)particles.push({x:player.x+dx/d*(40+i*30),y:player.y+dy/d*(40+i*30),vx:(Math.random()-0.5)*60,vy:(Math.random()-0.5)*60,life:0.25,maxLife:0.25,color:'#c084fc',size:2+Math.random()*2});
    }
  }

  // AFK auto-cast
  if(isAfk){for(let i=0;i<4;i++)if(now>=abilityCDs[i])playerCast(i);}

  // Spirits
  spirits=spirits.filter(s=>!s.dead);
  spirits.forEach(s=>{
    if(s.isTemp){s.lifetime-=dt*1000;if(s.lifetime<=0){s.dead=true;return;}}
    s.wobble+=dt*2.2;
    const or=70+Math.sin(s.wobble)*10;
    let haunt=s.hauntTarget&&!s.hauntTarget.dead&&s.hauntTarget.veilmarkStacks>0?s.hauntTarget:null;
    if(!haunt){s.hauntTarget=null;let bd=950;enemies.forEach(e=>{if(e.dead||e.veilmarkStacks<=0)return;const d=dist2(s.x,s.y,e.x,e.y);if(d<bd){bd=d;haunt=e;}});s.hauntTarget=haunt;}
    if(haunt){
      s.orbitAngle+=dt*3.8;
      const tx=haunt.x+Math.cos(s.orbitAngle)*or,ty=haunt.y+Math.sin(s.orbitAngle)*or;
      s.x+=(tx-s.x)*Math.min(1,dt*4.5);s.y+=(ty-s.y)*Math.min(1,dt*4.5);
      if(now-s.lastAttack>850){s.lastAttack=now;s.attackCount++;haunt.veilmarkStacks=Math.min(haunt.veilmarkStacks+1,10);hitEnemy(haunt,player.attack*0.32);}
    } else {
      let ne2=null,nd=720;
      enemies.forEach(e=>{if(e.dead)return;const d=dist2(s.x,s.y,e.x,e.y);if(d<nd){nd=d;ne2=e;}});
      if(ne2&&nd<340){
        const sdx=ne2.x-s.x,sdy=ne2.y-s.y,sd=Math.sqrt(sdx*sdx+sdy*sdy)||1;
        s.x+=sdx/sd*260*dt;s.y+=sdy/sd*260*dt;
        if(now-s.lastAttack>950&&sd<70){s.lastAttack=now;s.attackCount++;hitEnemy(ne2,player.attack*1.15);}
      } else {
        s.orbitAngle+=dt*2.4;
        const tx=player.x+Math.cos(s.orbitAngle)*or,ty=player.y+Math.sin(s.orbitAngle)*or;
        s.x+=(tx-s.x)*Math.min(1,dt*3.2);s.y+=(ty-s.y)*Math.min(1,dt*3.2);
      }
    }
    if(Math.random()<0.05)particles.push({x:s.x,y:s.y,vx:(Math.random()-0.5)*30,vy:-18-Math.random()*18,life:0.45,maxLife:0.45,color:'#9DC4B0',size:1.8});
  });

  // Enemies
  enemies.forEach(e=>{
    if(e.dead)return;
    if(e.hitFlash>0)e.hitFlash-=dt;
    const dx=player.x-e.x,dy=player.y-e.y,d=Math.sqrt(dx*dx+dy*dy)||1;
    if(d>e.size+24){e.x+=dx/d*e.speed*dt;e.y+=dy/d*e.speed*dt;}
    if(d<e.size+30&&now-e.lastAttack>1150){
      e.lastAttack=now;
      if(player.iframes<=0){player.hp-=e.attack;player.hitFlash=0.18;player.iframes=220;screenShake(6,130);SFX.playerHit();
        if(player.hp<=0){player.hp=0;player.isDead=true;document.getElementById('deathStats').textContent=`${kills} slain · Level ${player.level}`;document.getElementById('deathScreen').style.display='flex';}
      }
    }
    // Track nearest elite for boss bar
    if(e.isElite&&(!bossTarget||e.isElite)){
      const bd=dist2(player.x,player.y,e.x,e.y);
      if(bd<500)bossTarget=e;
    }
  });
  enemies=enemies.filter(e=>!e.dead);

  // Spawn
  spawnTimer+=dt*1000;
  const si=Math.max(1400,3000-player.level*42);
  if(spawnTimer>si){spawnTimer=0;spawnEnemy();}
  clusterTimer+=dt*1000;
  if(clusterTimer>clusterInterval){clusterTimer=0;clusterInterval=12000+Math.random()*9000;spawnCluster();}

  // Particles
  particles=particles.filter(p=>{p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.soul)p.vy-=dt*38;p.vx*=0.92;p.vy*=0.92;return p.life>0;});
  dmgTexts=dmgTexts.filter(d=>{d.life-=dt;d.wy+=d.vy*dt;d.wx+=d.vx*dt;d.vy*=0.9;return d.life>0;});
  if(shakeTimer>0)shakeTimer-=dt*1000;else shakeAmt*=0.75;

  camX+=(player.x-camX)*Math.min(1,dt*5.5);
  camY+=(player.y-camY)*Math.min(1,dt*5.5);
}

// ═══════ RENDER ═════════════════════════════════════════
function render(now){
  let sx=0,sy=0;
  if(shakeTimer>0&&shakeAmt>0.1){sx=(Math.random()-0.5)*shakeAmt;sy=(Math.random()-0.5)*shakeAmt;}

  // Screen-space background
  drawWorld(now);

  ctx.save();
  ctx.translate(W/2-camX+sx,H/2-camY+sy);

  // Veilmark rings on enemies (behind them)
  enemies.forEach(e=>{
    if(e.dead||e.veilmarkStacks<=0||performance.now()>e.veilmarkExpiry)return;
    const sa=e.veilmarkStacks/10;
    const ct=(performance.now()%1100)/1100;
    ctx.save();
    ctx.globalAlpha=0.4*sa;ctx.strokeStyle='#f43f5e';ctx.lineWidth=2;
    ctx.shadowColor='#f43f5e';ctx.shadowBlur=8;
    ctx.beginPath();ctx.arc(e.x,e.y,e.size*2*(1-ct*0.25),0,Math.PI*2);ctx.stroke();
    ctx.globalAlpha=1;
    ctx.fillStyle='#f43f5e';ctx.font='bold 11px monospace';ctx.textAlign='center';
    ctx.fillText(e.veilmarkStacks,e.x,e.y-e.size-6);
    ctx.restore();
  });

  // Particles (behind entities)
  particles.forEach(p=>{
    const a=p.life/p.maxLife;
    ctx.globalAlpha=a;ctx.fillStyle=p.color;
    ctx.shadowColor=p.color;ctx.shadowBlur=p.soul?12:5;
    ctx.beginPath();ctx.arc(p.x,p.y,p.size*(p.soul?a:1),0,Math.PI*2);ctx.fill();
  });
  ctx.globalAlpha=1;ctx.shadowBlur=0;

  // Spirits
  spirits.forEach(s=>drawSpirit(s,now));

  // Enemies
  enemies.forEach(e=>{
    if(e.dead)return;
    (e.typeData?.draw||drawWraith)(e,now);
    // HP bar
    const hpP=e.hp/e.maxHp,bw=e.size*3.2;
    ctx.fillStyle='rgba(0,0,0,0.7)';ctx.beginPath();ctx.roundRect(e.x-bw/2,e.y-e.size-16,bw,6,2);ctx.fill();
    const hpColor=hpP>0.6?'#22c55e':hpP>0.3?'#f59e0b':'#ef4444';
    ctx.fillStyle=hpColor;ctx.shadowColor=hpColor;ctx.shadowBlur=4;
    ctx.beginPath();ctx.roundRect(e.x-bw/2,e.y-e.size-16,bw*hpP,6,2);ctx.fill();
    ctx.shadowBlur=0;
    if(e.isElite){
      ctx.strokeStyle='#fbbf24';ctx.lineWidth=1.5;
      ctx.beginPath();ctx.roundRect(e.x-bw/2,e.y-e.size-16,bw,6,2);ctx.stroke();
      // Elite crown
      ctx.fillStyle='#fbbf24';ctx.shadowColor='#fbbf24';ctx.shadowBlur=6;
      ctx.font='10px serif';ctx.textAlign='center';ctx.fillText('👑',e.x,e.y-e.size-20);
      ctx.shadowBlur=0;
    }
  });

  // Player
  drawPlayer(now);

  // Damage numbers
  dmgTexts.forEach(d=>{
    const a=Math.min(1,d.life/d.maxLife*2);
    ctx.globalAlpha=a;
    ctx.font=`${d.isCrit?'bold ':''} ${d.isCrit?20:13}px 'Cinzel',serif`;
    ctx.fillStyle=d.color;ctx.textAlign='center';
    ctx.shadowColor=d.color;ctx.shadowBlur=d.isCrit?12:6;
    ctx.fillText(d.val,d.wx,d.wy);
  });
  ctx.globalAlpha=1;ctx.shadowBlur=0;

  ctx.restore();

  // ── Boss bar update ──
  if(bossTarget&&!bossTarget.dead){
    document.getElementById('bossBar').style.display='flex';
    document.getElementById('bossName').textContent=`⚔ ${bossTarget.typeData.name.toUpperCase()} — ELITE`;
    document.getElementById('bossBarFill').style.width=(bossTarget.hp/bossTarget.maxHp*100)+'%';
  } else {
    document.getElementById('bossBar').style.display='none';
    if(bossTarget&&bossTarget.dead)bossTarget=null;
  }

  updateHUD(now);
}

// ═══════ HUD UPDATE ═════════════════════════════════════
function updateHUD(now){
  document.getElementById('hpFill').style.width=(player.hp/player.maxHp*100)+'%';
  document.getElementById('xpFill').style.width=(player.xp/player.xpToNext*100)+'%';
  const sc=spirits.filter(s=>!s.dead).length;
  document.getElementById('spFill').style.width=(sc/(player.maxBonds||MAX_SPIRITS)*100)+'%';
  document.getElementById('levelBadge').textContent=`LV ${player.level}`;
  document.getElementById('hpNum').textContent=`${Math.ceil(player.hp)}`;
  document.getElementById('goldLabel').textContent=`💰 ${player.gold} G`;
  // Spirit pips
  const sp=document.getElementById('spiritPanel');sp.innerHTML='';
  const mb=player.maxBonds||MAX_SPIRITS;
  for(let i=0;i<mb;i++){const d=document.createElement('div');d.className='spip'+(i<sc?'':' dead');d.style.animationDelay=(i*0.18)+'s';sp.appendChild(d);}
  // Ability CDs
  for(let i=0;i<4;i++){
    const rem=Math.max(0,abilityCDs[i]-now),pct=rem/ABILITY_CDS[i];
    document.getElementById('ov'+i).style.height=(pct*100)+'%';
    const cdEl=document.getElementById('cd'+i);
    if(rem>0){cdEl.style.opacity='1';cdEl.textContent=Math.ceil(rem/1000)+'s';}else cdEl.style.opacity='0';
    document.getElementById('ab'+i).classList.toggle('ready',rem<=0);
  }
}

// ═══════ LOOP ════════════════════════════════════════════
function loop(ts){
  if(!running)return;
  const dt=Math.min((ts-lastTime)/1000,0.05);lastTime=ts;
  update(dt,ts);render(ts);
  requestAnimationFrame(loop);
}

// ═══════ START ═══════════════════════════════════════════
function startGame(){
  getAC(); // unlock audio context on user gesture
  document.getElementById('titleScreen').style.display='none';
  ['hud','abilityBar','feedLog','spiritPanel','menuBar','zoneLabel','minimap'].forEach(id=>{

    document.getElementById(id).style.display=
      (id==='abilityBar'||id==='menuBar')?'flex':'block';
  });
  player.maxHp=computeMaxHp(1);player.hp=player.maxHp;
  player.attack=computeAttack(1);player.maxBonds=MAX_SPIRITS;
  setAfkWaypoint();
  generateEnvironment();
  drawAbilityIcons();
  startMusic();
  for(let i=0;i<8;i++)setTimeout(()=>spawnEnemy(),i*400);
  running=true;lastTime=performance.now();
  requestAnimationFrame(loop);
  addFeed('THE VEIL CALLS YOU','#c084fc');
  addFeed('WASD/Arrow keys · Q W E R abilities','#3d2555');
}

// ═══════ INPUT ═══════════════════════════════════════════
document.addEventListener('keydown',e=>{keys[e.key]=true;player.lastInput=performance.now();});
document.addEventListener('keyup',e=>{keys[e.key]=false;});
document.getElementById('startBtn').addEventListener('click',startGame);

canvas.addEventListener('touchstart',e=>{
  e.preventDefault();
  const t=e.changedTouches[0];
  if(t.clientX<W/2){joyId=t.identifier;touchJoy.startX=t.clientX;touchJoy.startY=t.clientY;touchJoy.active=true;touchJoy.dx=0;touchJoy.dy=0;}
},{passive:false});
canvas.addEventListener('touchmove',e=>{
  e.preventDefault();
  for(let i=0;i<e.changedTouches.length;i++){
    const t=e.changedTouches[i];
    if(t.identifier===joyId){const dx=t.clientX-touchJoy.startX,dy=t.clientY-touchJoy.startY,m=Math.sqrt(dx*dx+dy*dy)||1;touchJoy.dx=dx/Math.max(m,50);touchJoy.dy=dy/Math.max(m,50);player.lastInput=performance.now();}
  }
},{passive:false});
canvas.addEventListener('touchend',e=>{for(let i=0;i<e.changedTouches.length;i++)if(e.changedTouches[i].identifier===joyId){touchJoy.active=false;touchJoy.dx=0;touchJoy.dy=0;joyId=null;}});

// ════════ ZONE TRANSITIONS ════════════════════════════════════════════
function checkZone(){
  const nz=ZONES.filter(z=>player.level>=z.minLv).pop();
  if(nz&&nz.id!==curZone.id){
    if(zoneTransiting)return;zoneTransiting=true;curZone=nz;
    SFX.zoneChange();
    showZTrans(nz.name,nz.tier,nz.ambColor);
    generateEnvironment();enemies=[];
    for(let i=0;i<8;i++)setTimeout(()=>spawnEnemy(),i*350);
    addFeed('★ ZONE: '+nz.name,'#e8b84b');
    setTimeout(()=>zoneTransiting=false,2600);
  }
}
function showZTrans(name,sub,color){
  const zt=document.getElementById('zoneTransition');
  const zn=document.getElementById('lvlUpTxt'),zs=document.getElementById('lvlUpUnlock');
  // Use a dedicated overlay
  let overlay=document.getElementById('ztOverlay');
  if(!overlay){overlay=document.createElement('div');overlay.id='ztOverlay';overlay.style.cssText='position:fixed;inset:0;z-index:350;pointer-events:none;opacity:0;transition:opacity 0.6s;background:rgba(0,0,0,0.92);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:12px';document.body.appendChild(overlay);}
  overlay.innerHTML='<div style="font-family:Cinzel,serif;font-size:clamp(1.5rem,5vw,2.8rem);font-weight:900;letter-spacing:0.3em;color:'+color+';filter:drop-shadow(0 0 20px '+color+')">'+name+'</div><div style="font-family:Cinzel,serif;font-size:0.7rem;letter-spacing:4px;color:'+color+';opacity:0.6">'+sub+'</div>';
  overlay.style.opacity='1';setTimeout(()=>{overlay.style.opacity='0';},2400);
}

// ════════ MINIMAP ═════════════════════════════════════════════════════
let _mmT=0;
function updateMinimapZ(){
  _mmT+=16;if(_mmT<200)return;_mmT=0;
  let mc=document.getElementById('minimapCanvas');
  if(!mc){mc=document.createElement('canvas');mc.id='minimapCanvas';mc.width=80;mc.height=80;mc.style.cssText='border-radius:50%;border:1px solid rgba(192,132,252,0.16);box-shadow:0 2px 10px rgba(0,0,0,0.6)';let wrap=document.getElementById('minimap');if(!wrap){wrap=document.createElement('div');wrap.id='minimap';wrap.style.cssText='position:fixed;top:10px;right:130px;z-index:50;pointer-events:none';document.body.appendChild(wrap);}wrap.appendChild(mc);if(running)wrap.style.display='block';}
  const mx=mc.getContext('2d'),mw=80,sc=mw/WORLD_W;
  mx.clearRect(0,0,mw,mw);mx.fillStyle='rgba(5,0,15,0.9)';mx.fillRect(0,0,mw,mw);
  enemies.forEach(e=>{if(e.dead)return;mx.fillStyle=e.isElite?'#fbbf24':'#ef4444';mx.beginPath();mx.arc(e.x*sc,e.y*sc,1.5,0,Math.PI*2);mx.fill();});
  spirits.forEach(s=>{if(s.dead)return;mx.fillStyle='#9DC4B0';mx.beginPath();mx.arc(s.x*sc,s.y*sc,1.2,0,Math.PI*2);mx.fill();});
  mx.fillStyle='#c084fc';mx.shadowColor='#c084fc';mx.shadowBlur=4;
  mx.beginPath();mx.arc(player.x*sc,player.y*sc,2.8,0,Math.PI*2);mx.fill();mx.shadowBlur=0;
}

